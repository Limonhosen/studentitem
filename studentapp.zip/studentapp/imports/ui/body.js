import { Template } from 'meteor/templating';
 
import { Tasks } from '../api/tasks.js';
 
import './body.html';

Template.bodyTemplate.events({
  'submit #submitInfo'(event) {
   
    event.preventDefault();
 
    const target = event.target;

    const infoData = {
      name: target.name.value,
      phone: target.phone.value,
      email: target.email.value,
      dateOfBirth: target.dateOfBirth.value,
      createdAt: new Date()
    };
 
    Tasks.insert(infoData);
 
    
     target.name.value = '';
     target.phone.value = '';
     target.email.value = '';
     target.dateOfBirth.value ='';
  },
});



Template.itemsListTemlate.helpers({
  getAllItems() {

    return Tasks.find({});
  },
});

Template.itemsListTemlate.events({

  'click .delete'(event) {

    Tasks.remove(this._id);

  },

});

